import type { NextConfig } from 'next';

const config: NextConfig = {
  poweredByHeader: false,
  ...(process.env.POLARBRIDGE_SANDBOX === '1' ? {
    experimental: { workerThreads: true, webpackBuildWorker: false, useTypeScriptCli: false, cpus: 2 },
  } : {}),
  async headers() {
    return [{ source: '/(.*)', headers: [
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      { key: 'X-Frame-Options', value: 'DENY' },
    ] }];
  },
};
export default config;
